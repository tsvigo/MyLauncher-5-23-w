package com.example.mylauncher

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AppAdapter(
    private val context: Context,
    private var apps: List<AppInfo>
) : RecyclerView.Adapter<AppAdapter.AppViewHolder>() {

    inner class AppViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val icon: ImageView = itemView.findViewById(R.id.appIcon)
        val name: TextView = itemView.findViewById(R.id.appName)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AppViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.app_item, parent, false)
        return AppViewHolder(view)
    }

    override fun onBindViewHolder(holder: AppViewHolder, position: Int) {
        val app = apps[position]
        holder.icon.setImageDrawable(app.icon)
        holder.name.text = app.name

        holder.itemView.setOnClickListener {
            context.startActivity(app.intent)
        }

        // 📌 длинный клик → показать меню пересылки
        holder.itemView.setOnLongClickListener { view ->
            val activity = context as MainActivity
            val popup = PopupMenu(context, view)

            val totalPages = activity.getPageCount()
            val appsPerPage = activity.getAppsPerPage()  // ✅ теперь доступен через метод

            for (pageIndex in 0 until totalPages) {
                val appsOnPage = activity.getAppsOnPage(pageIndex)
                if (appsOnPage.size < appsPerPage) {
                    popup.menu.add("Переслать на страницу ${pageIndex + 1}")
                        .setOnMenuItemClickListener {
                            activity.moveAppToPage(app, pageIndex)
                            true
                        }
                }
            }

            popup.show()
            true
        }
    }

    override fun getItemCount(): Int = apps.size

    fun updateApps(newApps: List<AppInfo>) {
        apps = newApps
        notifyDataSetChanged()
    }
}
