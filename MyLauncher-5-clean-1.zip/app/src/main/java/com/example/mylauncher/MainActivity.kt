package com.example.mylauncher

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.NumberPicker
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: AppAdapter
    private lateinit var pagePicker: NumberPicker
    private lateinit var confirmButton: Button

    private var apps: List<AppInfo> = emptyList()
    private var pages: MutableList<MutableList<AppInfo>> = mutableListOf()
    private var currentPage = 0
    private val appsPerPage = 36  // 4x9 сетка

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.recyclerView)
        pagePicker = findViewById(R.id.pagePicker)
        confirmButton = findViewById(R.id.confirmButton)

        recyclerView.layoutManager = GridLayoutManager(this, 4)

        loadApps()
        setupPages()

        // Настройка NumberPicker
        pagePicker.minValue = 1
        pagePicker.maxValue = pages.size
        pagePicker.wrapSelectorWheel = false

        // Кнопка "Хорошо" → переход к выбранной странице
        confirmButton.setOnClickListener {
            val selectedPage = pagePicker.value - 1
            if (selectedPage in pages.indices) {
                currentPage = selectedPage
                showPage(currentPage)
            }
        }
    }

    private fun loadApps() {
        val pm: PackageManager = packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        apps = pm.queryIntentActivities(intent, 0).map {
            val appIntent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
                setClassName(it.activityInfo.packageName, it.activityInfo.name)
            }
            AppInfo(
                name = it.loadLabel(pm).toString(),
                icon = it.loadIcon(pm),
                intent = appIntent
            )
        }.sortedBy { it.name }
    }

    private fun setupPages() {
        pages = apps.chunked(appsPerPage).map { it.toMutableList() }.toMutableList()
        currentPage = 0
        showPage(currentPage)
    }

    private fun showPage(pageIndex: Int) {
        if (pageIndex in pages.indices) {
            adapter = AppAdapter(this, pages[pageIndex])
            recyclerView.adapter = adapter
        }
    }

    // 📌 публичные методы для AppAdapter

    fun getPageCount(): Int = pages.size

    fun getAppsOnPage(pageIndex: Int): List<AppInfo> =
        if (pageIndex in pages.indices) pages[pageIndex] else emptyList()

    fun getAppsPerPage(): Int = appsPerPage

    fun moveAppToPage(app: AppInfo, targetPage: Int) {
        if (targetPage !in pages.indices) return

        // удалить из текущей страницы
        pages.forEach { it.remove(app) }

        // добавить на целевую
        if (pages[targetPage].size < appsPerPage) {
            pages[targetPage].add(app)
        }

        // обновить UI
        showPage(currentPage)
    }
}
