package com.example.mylauncher

import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.widget.Button
import android.widget.NumberPicker
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: AppAdapter
    private lateinit var pagePicker: NumberPicker
    private lateinit var goButton: Button
    private lateinit var pageCountText: TextView

    private var apps: MutableList<AppInfo> = mutableListOf()
    private var currentPage = 0
    private val appsPerPage = 32   // 4 x 8

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.recyclerView)
        pagePicker = findViewById(R.id.pagePicker)
        goButton = findViewById(R.id.goButton)
        pageCountText = findViewById(R.id.pageCountText)

        recyclerView.layoutManager = GridLayoutManager(this, 4) // 4 колонки
        adapter = AppAdapter(this, listOf())
        recyclerView.adapter = adapter

        loadApps()
        updatePage()
        updatePageControls()

        goButton.setOnClickListener {
            currentPage = pagePicker.value - 1
            updatePage()
        }
    }

    private fun loadApps() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN, null)
        intent.addCategory(Intent.CATEGORY_LAUNCHER)

        val resolveInfos = pm.queryIntentActivities(intent, 0)
        apps.clear()

        for (ri in resolveInfos) {
            val appName = ri.loadLabel(pm).toString()
            val appIcon: Drawable = ri.loadIcon(pm)
            val launchIntent: Intent = pm.getLaunchIntentForPackage(ri.activityInfo.packageName) ?: continue
            apps.add(AppInfo(appName, appIcon, launchIntent))
        }

        apps.sortBy { it.name }
    }

    private fun updatePage() {
        val fromIndex = currentPage * appsPerPage
        val toIndex = minOf(fromIndex + appsPerPage, apps.size)
        val pageApps = if (fromIndex < apps.size) apps.subList(fromIndex, toIndex) else emptyList()
        adapter.updateApps(pageApps)
        updatePageControls()
    }

    private fun updatePageControls() {
        val pageCount = getPageCount()
        pagePicker.minValue = 1
        pagePicker.maxValue = pageCount
        pagePicker.value = currentPage + 1
        pageCountText.text = "Всего экранов: $pageCount"
    }

    fun getPageCount(): Int {
        return if (apps.isEmpty()) 1 else (apps.size + appsPerPage - 1) / appsPerPage
    }

    fun getAppsOnPage(pageIndex: Int): List<AppInfo> {
        val fromIndex = pageIndex * appsPerPage
        val toIndex = minOf(fromIndex + appsPerPage, apps.size)
        return if (fromIndex < apps.size) apps.subList(fromIndex, toIndex) else emptyList()
    }

    fun moveAppToPage(app: AppInfo, pageIndex: Int) {
        apps.remove(app)
        val insertIndex = minOf(pageIndex * appsPerPage, apps.size)
        apps.add(insertIndex, app)
        updatePage()
    }
}
